# Reference Guide Skill

Create ML/AI reference guides following a consistent, neurodivergent-friendly format.

## Two-File Pattern

Every topic gets two files:

1. **`*_Reference.md`**: Syntax and parameters. Copy-paste ready. For when you know what you want.
2. **`*_Concepts.md`**: Theory and decisions. The why behind the what. For when you need to understand.

Never mix syntax-heavy and theory-heavy content in the same file.

## Reference File Structure

```markdown
# [Topic] - Quick Reference

[One-line purpose statement]

---

## Basic Syntax

[Complete, runnable code block with inline comments]

---

## Key Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `param1` | type | What it does. Default=X |

---

## [Compatibility/Matrix Section if applicable]

| Option | A | B | C |
|--------|---|---|---|
| X | ✓ | ✗ | ✓ |

---

## Attributes (after fit) [if applicable]

[Code block showing how to access results]

---

## Example: [Variation 1]

[Runnable code]

---

## Example: [Variation 2]

[Runnable code]

---

## Common Pitfalls - Quick Fixes

| Issue | Symptom | Fix |
|-------|---------|-----|
| Problem | What you see | What to do |

---

## Key Takeaways

1. Point one
2. Point two
3. Point three
```

## Concepts File Structure

```markdown
# [Topic] - Concepts

[One-line summary of what this explains]

---

## Purpose / Why This Matters

[Brief context: what problem does this solve]

---

## [Core Concept 1]

### What It Is
[Definition]

### What It Measures / Does
[Behavior]

### Use When
[Conditions]

### Limitation
[Trade-offs, gotchas]

---

## [Core Concept 2]

[Same pattern]

---

## Decision Framework

[ASCII decision tree]

```
Start here
    |
    v
Question 1?
    |
    +-- Yes -> Action A
    |
    +-- No -> Question 2?
              |
              +-- Yes -> Action B
              +-- No -> Action C
```

---

## Interpreting Results

### Example Output

[Table with realistic numbers]

### What to Look For

**1. Pattern Name**
[What it means, what to do]

**2. Pattern Name**
[What it means, what to do]

---

## Common Pitfalls

### 1. Pitfall Name

**Mistake:** What people do wrong

**Why it's wrong:** The actual problem

**Fix:** What to do instead

---

## Key Takeaways

1. Point one
2. Point two
3. Point three
```

## Formatting Rules

### Do

- Tables for comparisons, parameters, options
- ASCII decision trees for conditional logic
- Code blocks that actually run (test them)
- Horizontal rules (`---`) between sections
- Bold for key terms: `**term**`
- Colons after bold terms: `**Term:** explanation`
- Checkmarks in tables: `✓` and `✗`
- Explicit "Use when" and "Limitation" for every concept

### Do Not

- Em dashes (`—`): use colons, commas, or periods
- Long prose paragraphs: break into bullets or tables
- "It depends" without decision tree
- Pseudocode: real code or nothing
- Mixing syntax and theory in same section
- Assuming knowledge without stating it
- Vague advice: be specific or don't say it

## ND-Friendly Principles

1. **Scannable structure**: Headers, tables, bullets. Never hide information in paragraphs.

2. **Separated concerns**: Syntax file for doing, concepts file for understanding. Reader chooses.

3. **Explicit logic**: Decision trees show exactly when to use what. No implicit knowledge.

4. **No hidden assumptions**: If something matters, state it. If you need X first, say so.

5. **Visual over verbal**: Table comparing 5 options beats 5 paragraphs explaining each.

6. **Copy-paste ready**: Code works. Parameters are real. Examples are complete.

## Code Block Standards

```python
# Good: Complete, runnable, commented
from sklearn.linear_model import LogisticRegression

model = LogisticRegression(
    C=1.0,                    # regularization strength
    penalty='l2',             # L2 = Ridge
    solver='lbfgs',           # default, works with L2
    class_weight='balanced',  # handle imbalance
    max_iter=5000,            # increase if convergence warning
    random_state=42
)
model.fit(X_train, y_train)
```

```python
# Bad: Incomplete, won't run
model = LogisticRegression(penalty='l2')
# then fit it...
```

## Table Standards

### Parameter Tables

| Parameter | Type | Description |
|-----------|------|-------------|
| `C` | float | Inverse regularization strength. Higher = less penalty. Default=1.0 |
| `penalty` | str | `'l1'`, `'l2'`, `'elasticnet'`, `None` |

- First column: parameter name in backticks
- Include type
- Include default if not obvious
- List valid options for categorical params

### Comparison Tables

| Aspect | Option A | Option B | Option C |
|--------|----------|----------|----------|
| Speed | Fast | Slow | Medium |
| Memory | Low | High | Medium |
| Use when | Condition | Condition | Condition |

- First column: what's being compared
- Keep cells short (1-3 words ideal)
- "Use when" row if applicable

### Pitfall Tables

| Issue | Symptom | Fix |
|-------|---------|-----|
| KNN with imbalance | Poor recall despite tuning | Exclude or use SMOTE |

- Issue: brief name
- Symptom: what you observe
- Fix: concrete action

## Decision Tree Standards

```
Question (yes/no or condition)?
    |
    +-- Option A -> Result or next question
    |
    +-- Option B -> Result or next question
              |
              +-- Sub-option -> Result
```

- Start with most important decision
- Max 3-4 levels deep
- Leaf nodes are concrete actions
- Use `->` for results, not descriptions

## Naming Convention

```
[Topic]_Reference.md      # Syntax, parameters, examples
[Topic]_Concepts.md       # Theory, decisions, interpretation

# Examples:
LogisticRegressionCV_Reference.md
LogisticRegression_Concepts.md
QualificationModelSelection_Reference.md
QualificationModelSelection_Concepts.md
```

## Quality Checklist

Before finalizing:

- [ ] No em dashes anywhere
- [ ] All code blocks are runnable
- [ ] Tables instead of comparison prose
- [ ] Decision tree for "when to use" questions
- [ ] Key takeaways at end
- [ ] Reference file has no theory paragraphs
- [ ] Concepts file explains why, not just how
- [ ] Every concept has "Use when" and limitation
